module.exports = {
  entry: "./lib/agar.js",
  output: {
  	filename: "./lib/bundle.js"
  },
  devtool: 'source-map',
};
